# Welcome to crafty!
Crafty is a web app developed in java which aims to allow you to search across multiple art supply stores for the products you want. Shop local? Add your favourite products to Crafty's Catalogue to compare it again prices at other art stores.

See what I can do: http://localhost:8080/COMP4601_FINAL_SERVER/crafty/query/copic+marker
