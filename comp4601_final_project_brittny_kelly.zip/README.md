# Welcome to crafty!
See what I can do: http://localhost:8080/COMP4601_FINAL_SERVER/crafty/query/copic+marker
